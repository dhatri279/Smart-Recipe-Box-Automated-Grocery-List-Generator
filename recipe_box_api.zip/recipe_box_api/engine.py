from bson import ObjectId
from datetime import datetime
from config import get_database

db = get_database()
recipes_collection = db["recipes"]
# New collection for storing generated manifests
shopping_lists_collection = db["shopping_lists"] 

def combine_and_aggregate(recipe_ids: list[str]) -> dict:
    combined_items = {}
    
    # Unit Conversion Matrix (Normalized to Cups)
    UNIT_CONVERSIONS = {
        "tbsp": {"target": "cups", "factor": 1 / 16},  # 16 tbsp = 1 cup
        "tsp": {"target": "cups", "factor": 1 / 48},   # 48 tsp = 1 cup
        "tablespoon": {"target": "cups", "factor": 1 / 16},
        "teaspoon": {"target": "cups", "factor": 1 / 48}
    }
    
    for r_id in recipe_ids:
        recipe = recipes_collection.find_one({"_id": ObjectId(r_id)})
        if not recipe:
            continue
            
        for ing in recipe["ingredients"]:
            name_norm = ing["name"].strip().lower()
            unit_norm = ing["unit"].strip().lower()
            quantity = ing["quantity"]
            
            # If the unit is a sub-unit (like tbsp or tsp), convert it to cups instantly
            if unit_norm in UNIT_CONVERSIONS:
                target_unit = UNIT_CONVERSIONS[unit_norm]["target"]
                quantity = quantity * UNIT_CONVERSIONS[unit_norm]["factor"]
                unit_norm = target_unit
            
            unique_key = f"{name_norm}_{unit_norm}"
            
            if unique_key in combined_items:
                combined_items[unique_key]["quantity"] += quantity
            else:
                combined_items[unique_key] = {
                    "name": ing["name"],
                    "quantity": quantity,
                    "unit": unit_norm,
                    "category": ing["category"].strip().capitalize()
                }
                
    # Group the elements into grocery categories
    categorized_list = {}
    for item in combined_items.values():
        cat = item["category"]
        if cat not in categorized_list:
            categorized_list[cat] = []
        categorized_list[cat].append(item)
        
    # Save to MongoDB permanently
    from datetime import datetime
    timestamp_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    shopping_list_document = {
        "source_recipe_ids": recipe_ids,   
        "grocery_list": categorized_list,
        "saved_at": timestamp_str
    }
    
    result = shopping_lists_collection.insert_one(shopping_list_document)
    
    final_response = {
        "shopping_list_id": str(result.inserted_id),
        "saved_at": timestamp_str,
        "categories": categorized_list
    }
    
    return final_response