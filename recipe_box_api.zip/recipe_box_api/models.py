from pydantic import BaseModel, Field
from typing import List

class Ingredient(BaseModel):
    name: str = Field(..., example="all-purpose flour")
    quantity: float = Field(..., example=1.5)
    unit: str = Field(..., example="cups")
    category: str = Field(..., example="Pantry")

class Recipe(BaseModel):
    title: str = Field(..., example="Classic Pancakes")
    servings: int = Field(..., example=4)
    ingredients: List[Ingredient]