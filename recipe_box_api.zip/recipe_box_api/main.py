from fastapi import FastAPI, HTTPException
from typing import List
from models import Recipe
from engine import recipes_collection, combine_and_aggregate
from bson import ObjectId
from fastapi import Request
from fastapi.responses import JSONResponse
from pymongo.errors import PyMongoError
from config import get_database

app = FastAPI(
    title="Smart Recipe Box & Grocery API",
    description="Production-ready REST API for combining recipe ingredient manifests.",
    version="1.0.0"
)

db=get_database()
# Absolute Global Database Exception Guard Rail
@app.middleware("http")
async def db_safeguard_middleware(request: Request, call_next):
    try:
        # Before doing anything, quickly ping MongoDB to see if it's alive
        db.command("ping")
        
        # If alive, proceed normally
        response = await call_next(request)
        return response
    except PyMongoError:
        # If MongoDB is completely stopped, catch it instantly here!
        return JSONResponse(
            status_code=503,
            content={
                "status": "Offline",
                "error": "Database Service Temporarily Unavailable",
                "details": "The backend middleware safely intercepted a database connection loss. FastAPI remains online."
            }
        )
    
# 1. Endpoint: Check if API is active
@app.get("/")
def read_root():
    return {"status": "Online", "message": "Welcome to the Smart Recipe Box API"}

# 2. Endpoint: Save a New Recipe
@app.post("/recipes", status_code=201)
def add_recipe(recipe: Recipe):
    # Convert Pydantic object directly into a standard Python dictionary for MongoDB
    recipe_dict = recipe.dict()
    result = recipes_collection.insert_one(recipe_dict)
    return {
        "message": "Recipe successfully created",
        "recipe_id": str(result.inserted_id)
    }

# 3. Endpoint: View All Stored Recipes
@app.get("/recipes")
def view_all_recipes():
    recipes = list(recipes_collection.find())
    output = []
    for r in recipes:
        output.append({
            "id": str(r["_id"]),
            "title": r["title"],
            "servings": r["servings"],
            "ingredients_count": len(r["ingredients"])
        })
    return output

# 4. Endpoint: Generate Consolidated Shopping List
@app.post("/recipes/shopping-list")
def generate_shopping_list(recipe_ids: List[str]):
    try:
        final_list = combine_and_aggregate(recipe_ids)
        return final_list
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error executing aggregation logic: {str(e)}")
    
# 5. CRUD Operation: UPDATE a Recipe by its ID
@app.put("/recipes/{recipe_id}")
def update_recipe(recipe_id: str, updated_recipe: Recipe):
    if not ObjectId.is_valid(recipe_id):
        raise HTTPException(status_code=400, detail="Invalid MongoDB ObjectId format")
        
    # Convert Pydantic object to a dictionary for MongoDB
    update_data = updated_recipe.dict()
    
    result = recipes_collection.replace_one({"_id": ObjectId(recipe_id)}, update_data)
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Recipe not found")
        
    return {"message": "Recipe updated successfully", "recipe_id": recipe_id}


# 6. CRUD Operation: DELETE a Recipe by its ID
@app.delete("/recipes/{recipe_id}")
def delete_recipe(recipe_id: str):
    if not ObjectId.is_valid(recipe_id):
        raise HTTPException(status_code=400, detail="Invalid MongoDB ObjectId format")
        
    result = recipes_collection.delete_one({"_id": ObjectId(recipe_id)})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Recipe not found")
        
    return {"message": f"Recipe with ID {recipe_id} was deleted successfully"}